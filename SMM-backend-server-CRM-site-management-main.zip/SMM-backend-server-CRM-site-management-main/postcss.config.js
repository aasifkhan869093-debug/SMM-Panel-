module.exports = {
    plugins: {
        autoprefixer: {},
    },
};
